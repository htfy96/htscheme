var types_2arch_8hpp =
[
    [ "PARSER_DECLARATION", "types_2arch_8hpp.html#a669f5b829a7373f20602e4c063e01d99", null ],
    [ "TokenType", "types_2arch_8hpp.html#aa520fbf142ba1e7e659590c07da31921", [
      [ "LeftParenthesis", "types_2arch_8hpp.html#aa520fbf142ba1e7e659590c07da31921a0e229922772e1ebbe231bb76b1d0674e", null ],
      [ "RightParenthesis", "types_2arch_8hpp.html#aa520fbf142ba1e7e659590c07da31921aa6ae499ba91edf718de60cefdb91e070", null ],
      [ "OpPlus", "types_2arch_8hpp.html#aa520fbf142ba1e7e659590c07da31921a553e6f09de6793cb7e48368fae2c7afe", null ],
      [ "OpMinus", "types_2arch_8hpp.html#aa520fbf142ba1e7e659590c07da31921aaa3c8287ef3b1b2f65ca22def9d514c8", null ],
      [ "OpMultiply", "types_2arch_8hpp.html#aa520fbf142ba1e7e659590c07da31921aa18a9690cbc2e7c5e8df90b8278b9221", null ],
      [ "OpDivide", "types_2arch_8hpp.html#aa520fbf142ba1e7e659590c07da31921a6271add987abf4c1f4c420ffa7b505ac", null ],
      [ "Float", "types_2arch_8hpp.html#aa520fbf142ba1e7e659590c07da31921ad67b0ee7230dcecb610254e4e5e589cd", null ],
      [ "Rational", "types_2arch_8hpp.html#aa520fbf142ba1e7e659590c07da31921ac484461d6c31e2ef0d6ea82009ad1575", null ],
      [ "String", "types_2arch_8hpp.html#aa520fbf142ba1e7e659590c07da31921ade17ec82ff106e0c2b4417f5ca231eae", null ],
      [ "Boolean", "types_2arch_8hpp.html#aa520fbf142ba1e7e659590c07da31921a3e74f2723415f1cc3cc2f3883f68add8", null ]
    ] ]
];