var struct_token =
[
    [ "info", "struct_token.html#a4c338f6ca199f4a8575e877d36d03a06", null ],
    [ "raw", "struct_token.html#ad77981ec051c2380c38459f8c4392dad", null ],
    [ "tokenType", "struct_token.html#a3d2b3146021ae2acd9e1b33bf5e59c78", null ]
];