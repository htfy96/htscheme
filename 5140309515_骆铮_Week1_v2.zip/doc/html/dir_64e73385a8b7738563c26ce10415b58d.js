var dir_64e73385a8b7738563c26ce10415b58d =
[
    [ "bigint.cpp", "bigint_8cpp.html", "bigint_8cpp" ],
    [ "bigint.hpp", "bigint_8hpp.html", [
      [ "BigInt", "class_big_int.html", "class_big_int" ]
    ] ],
    [ "debug.cpp", "debug_8cpp.html", "debug_8cpp" ],
    [ "debug.hpp", "debug_8hpp.html", "debug_8hpp" ],
    [ "rationaltype.cpp", "rationaltype_8cpp.html", "rationaltype_8cpp" ],
    [ "rationaltype.hpp", "rationaltype_8hpp.html", [
      [ "RationalType", "class_rational_type.html", "class_rational_type" ]
    ] ],
    [ "simplenum.cpp", "simplenum_8cpp.html", "simplenum_8cpp" ],
    [ "simplenum.hpp", "simplenum_8hpp.html", "simplenum_8hpp" ],
    [ "strutility.hpp", "strutility_8hpp.html", "strutility_8hpp" ]
];