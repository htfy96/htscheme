var searchData=
[
  ['raw',['raw',['../struct_token.html#ad77981ec051c2380c38459f8c4392dad',1,'Token']]],
  ['rawtokens',['rawTokens',['../class_tokenizer.html#a89707ad3a758fc9ec58f00d92d5fc622',1,'Tokenizer']]]
];
