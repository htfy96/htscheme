var searchData=
[
  ['banner',['banner',['../cli_8cpp.html#a575d73a6aa36ed1a2a565301481cf822',1,'cli.cpp']]],
  ['buf',['buf',['../cli_8cpp.html#a1fe855c208bc17a51a4d34fefdb2d5b1',1,'cli.cpp']]]
];
