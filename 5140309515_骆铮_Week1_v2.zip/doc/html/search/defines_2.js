var searchData=
[
  ['log',['LOG',['../debug_8hpp.html#a8a4ff11a20721b066204b813fe37099a',1,'debug.hpp']]],
  ['log_5fimpl',['LOG_IMPL',['../debug_8hpp.html#a5d3aac75cc976733b5192104f4fa7192',1,'debug.hpp']]]
];
