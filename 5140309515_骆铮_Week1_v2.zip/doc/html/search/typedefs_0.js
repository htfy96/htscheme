var searchData=
[
  ['booleantype',['BooleanType',['../boolean_8hpp.html#a0302c79f6d6b93d902af278d1191e054',1,'boolean.hpp']]]
];
