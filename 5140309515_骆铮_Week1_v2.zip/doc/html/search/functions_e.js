var searchData=
[
  ['tokenizer',['Tokenizer',['../class_tokenizer.html#a2a6c04ea8c784f66bebcb6df7073769c',1,'Tokenizer::Tokenizer()'],['../class_tokenizer.html#a6edc9ba4af94d2aa55f48a83c903800f',1,'Tokenizer::Tokenizer(const std::vector&lt; std::string &gt; &amp;lines)']]]
];
