var debug_8hpp =
[
    [ "LOG", "debug_8hpp.html#a8a4ff11a20721b066204b813fe37099a", null ],
    [ "LOG_IMPL", "debug_8hpp.html#a5d3aac75cc976733b5192104f4fa7192", null ],
    [ "INDEBUG", "debug_8hpp.html#a16d89d714be4d85e0b9faec4dc086980", null ]
];