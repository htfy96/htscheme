var simplenum_8cpp =
[
    [ "isSimpleFloat", "simplenum_8cpp.html#add6b0df1f5d6bf72c159331a157e8760", null ],
    [ "isSimpleInt", "simplenum_8cpp.html#a3c42e7ba34ef531b4013bd178e7e0565", null ]
];