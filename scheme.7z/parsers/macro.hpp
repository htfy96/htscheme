
#ifndef __SCHEME_PARSERS_MACRO
#define __SCHEME_PARSERS_MACRO
#include "arch.hpp"

ASTParserBuilder(MacroASTParser)

#endif
