
#ifndef __SCHEME_PARSERS_LAMBDA
#define __SCHEME_PARSERS_LAMBDA
#include "arch.hpp"

ASTParserBuilder(LambdaASTParser)

#endif
