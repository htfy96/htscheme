#ifndef __SCHEME_PARSERS_OPIF
#define __SCHEME_PARSERS_OPIF
#include "ast.hpp"
#include "arch.hpp"

ASTParserBuilder(OpIfASTParser)

#endif
