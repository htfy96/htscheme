#ifndef __SCHEME_PARSERS_LAMBDADEFINE
#define __SCHEME_PARSERS_LAMBDADEFINE
#include "arch.hpp"

ASTParserBuilder(LambdaDefineASTParser)

#endif
