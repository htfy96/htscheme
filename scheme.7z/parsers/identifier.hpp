#ifndef __SCHEME_PARSERS_IDENTIFIER
#define __SCHEME_PARSERS_IDENTIFIER
#include "arch.hpp"

ASTParserBuilder(IdentifierASTParser)

#endif
