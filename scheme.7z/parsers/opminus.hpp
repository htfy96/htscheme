#ifndef __SCHEME_PARSERS_OPMINUS
#define __SCHEME_PARSERS_OPMINUS
#include "ast.hpp"
#include "arch.hpp"

ASTParserBuilder(OpMinusASTParser)

#endif
