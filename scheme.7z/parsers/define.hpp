#ifndef __SCHEME_PARSERS_DEFINE
#define __SCHEME_PARSERS_DEFINE
#include "arch.hpp"

ASTParserBuilder(DefineASTParser)

#endif
