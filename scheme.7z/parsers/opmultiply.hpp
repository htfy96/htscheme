#ifndef __SCHEME_PARSERS_OPMULTIPLY
#define __SCHEME_PARSERS_OPMULTIPLY
#include "ast.hpp"
#include "arch.hpp"

ASTParserBuilder(OpMultiplyASTParser)


#endif
