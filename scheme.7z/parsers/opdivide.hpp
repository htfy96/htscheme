#ifndef __SCHEME_PARSERS_OPDIVIDE
#define __SCHEME_PARSERS_OPDIVIDE
#include "ast.hpp"
#include "arch.hpp"

ASTParserBuilder(OpDivideASTParser)
#endif
