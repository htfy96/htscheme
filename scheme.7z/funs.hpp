#ifndef __SCHEME_FUNS
#define __SCHEME_FUNS

#include "funs/all.hpp"

#endif
