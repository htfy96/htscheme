#ifndef __SCHEME_FUNS_GCD
#define __SCHEME_FUNS_GCD
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void gcd(PASTNode, ParsersHelper&);
}
#endif
