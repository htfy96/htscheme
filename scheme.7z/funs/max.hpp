#ifndef __SCHEME_FUNS_MAX
#define __SCHEME_FUNS_MAX
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void max(PASTNode, ParsersHelper&);
}
#endif
