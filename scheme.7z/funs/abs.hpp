#ifndef __SCHEME_FUNS_ABS
#define __SCHEME_FUNS_ABS
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void abs(PASTNode, ParsersHelper&);
}
#endif
