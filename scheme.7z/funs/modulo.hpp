
#ifndef __SCHEME_FUNS_MODULO
#define __SCHEME_FUNS_MODULO
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void modulo(PASTNode, ParsersHelper&);
}
#endif
