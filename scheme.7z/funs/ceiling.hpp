#ifndef __SCHEME_FUNS_CEILING
#define __SCHEME_FUNS_CEILING
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void ceiling(PASTNode, ParsersHelper&);
}
#endif
