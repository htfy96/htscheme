#ifndef __SCHEME_FUNS_ROUND
#define __SCHEME_FUNS_ROUND
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void round(PASTNode, ParsersHelper&);
}
#endif
