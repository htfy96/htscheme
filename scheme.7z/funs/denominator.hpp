#ifndef __SCHEME_FUNS_DENOMINATOR
#define __SCHEME_FUNS_DENOMINATOR
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void denominator(PASTNode, ParsersHelper&);
}
#endif
