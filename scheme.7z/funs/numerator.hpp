#ifndef __SCHEME_FUNS_NUMERATOR
#define __SCHEME_FUNS_NUMERATOR
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void numerator(PASTNode, ParsersHelper&);
}
#endif
