#ifndef __SCHEME_FUNS_SQRT
#define __SCHEME_FUNS_SQRT
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void sqrt(PASTNode, ParsersHelper&);
}
#endif
