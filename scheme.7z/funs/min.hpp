#ifndef __SCHEME_FUNS_MIN
#define __SCHEME_FUNS_MIN
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void min(PASTNode, ParsersHelper&);
}
#endif
