
#ifndef __SCHEME_FUNS_EQUAL
#define __SCHEME_FUNS_EQUAL
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void equal(PASTNode, ParsersHelper&);
}
#endif
