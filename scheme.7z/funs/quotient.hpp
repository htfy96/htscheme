#ifndef __SCHEME_FUNS_QUOTIENT
#define __SCHEME_FUNS_QUOTIENT
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void quotient(PASTNode, ParsersHelper&);
}
#endif
