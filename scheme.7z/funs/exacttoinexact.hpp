#ifndef __SCHEME_FUNS_EXACTTOINEXACT
#define __SCHEME_FUNS_EXACTTOINEXACT
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void exactToInexact(PASTNode, ParsersHelper&);
}
#endif
