
#ifndef __SCHEME_FUNS_REMAINDER
#define __SCHEME_FUNS_REMAINDER
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void remainder(PASTNode, ParsersHelper&);
}
#endif
