

#ifndef __SCHEME_FUNS_INEXACTTOEXACT
#define __SCHEME_FUNS_INEXACTTOEXACT
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void inexactToExact(PASTNode, ParsersHelper&);
}
#endif
