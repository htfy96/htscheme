#ifndef __SCHEME_FUNS_EXPT
#define __SCHEME_FUNS_EXPT
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void expt(PASTNode, ParsersHelper&);
}
#endif
