
#ifndef __SCHEME_FUNS_FLOOR
#define __SCHEME_FUNS_FLOOR
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void floor(PASTNode, ParsersHelper&);
}
#endif
