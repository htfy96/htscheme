
#ifndef __SCHEME_FUNS_REALPART
#define __SCHEME_FUNS_REALPART
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void realpart(PASTNode, ParsersHelper&);
}
#endif
