
#ifndef __SCHEME_FUNS_IMAGPART
#define __SCHEME_FUNS_IMAGPART
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void imagpart(PASTNode, ParsersHelper&);
}
#endif
