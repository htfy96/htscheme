#ifndef __SCHEME_FUNS_LCM
#define __SCHEME_FUNS_LCM
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void lcm(PASTNode, ParsersHelper&);
}
#endif
