#ifndef __SCHEME_FUNS_ARCH
#define __SCHEME_FUNS_ARCH
#include "ast.hpp"
#include "parsers.hpp"
#include <cmath>
//Pending
#endif
