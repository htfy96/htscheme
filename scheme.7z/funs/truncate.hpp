
#ifndef __SCHEME_FUNS_TRUNCATE
#define __SCHEME_FUNS_TRUNCATE
#include "arch.hpp"
#include "ast.hpp"
#include "parsers.hpp"
namespace HT
{
    void truncate(PASTNode, ParsersHelper&);
}
#endif
